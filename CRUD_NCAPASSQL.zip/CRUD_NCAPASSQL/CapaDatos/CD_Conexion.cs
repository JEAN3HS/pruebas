﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace CapaDatos
{
    internal class CD_Conexion
    {
        private SqlConnection Conexion = new SqlConnection ("Server=LAPTOP-B3Q8K4K8;DataBase=Practica; user id=sesionlp ;password=lp2022;");

        public SqlConnection AbrirConexion()
        {
            if(Conexion.State == ConnectionState.Closed)
                Conexion.Open ();
            return Conexion;
        }
        public SqlConnection CerrarConexion()
        {
            if(Conexion.State == ConnectionState.Open)
                Conexion.Close ();
            return Conexion ;
        }
    }
}
